DOCCRAFT STUDIO WEBSITE

1. Open index.html in a browser to preview.
2. Replace YOUR_EMAIL@example.com with your real email address.
3. Replace the LinkedIn link with your profile URL.
4. Replace portfolio placeholders with genuine sample project previews before publishing.

FREE PUBLISHING OPTION:
Use GitHub Pages: create a free GitHub account, create a public repository named doccraft-studio, upload index.html and logo.png (if included), then enable Pages in repository Settings > Pages > Deploy from branch > main / root.

This is a static website package. It is not yet published and does not create a live URL until you upload it to a hosting service.
